//Name:						Will Arthur
//Course:					CS 2010
//Time:						9:30-10:30
//Program Number:			4
//File Name:				ArthurW-Program4
//Due Date:					November 5, 2017
//Purpose:					Determine if a user inputed phrase is a palindrome
//Input Data Needed:		User must input a series of characters
//Processing/Calculations:	fff
//Results:					The program will either tell the user that their phrase is or is not a palindrome and ask if they'd like to continue

#include <iostream>
#include <string>

using namespace std;

int main()
{
	//Declaration
	string line, compLine, upperLine, revLine;
	char letter, upperLetter, revLetter, cont;
	int i, len;
	bool again = true;
	bool go = true;

	do
	{
		//Getting Line
		cout << "Enter a phrase: ";
		getline(cin, line);

		//Getting Length
		len = line.length();

		//Compression loop
		i = 0;
		compLine = "";
		while (i < len)
		{
			letter = line.at(i);
			if (letter >= 65 && letter <= 90 || letter >= 97 && letter <= 122)
			{
				compLine += letter;
			}
			i++;
		}

		//Uppercase
		len = compLine.length();
		i = 0;
		upperLine = "";
		while (i < len)
		{
			letter = compLine.at(i);
			if (letter >= 97 && letter <= 122)
				upperLetter = letter - 32;
			else
				upperLetter = letter;
			upperLine += upperLetter;
			i++;
		}

		//Reverse
		i = 0;
		revLine = "";
		while (i < len)
		{
			letter = upperLine.at(len - 1);
			revLine += letter;
			len--;
		}

		//comparison
		if (revLine == upperLine)
			cout << "User input is a palindrome" << endl;
		else
			cout << "User input is not a palindrome" << endl;

		//If they'd like to continue
		do
		{
			cout << "Would user like to run the program again (Y or N): ";
			cin >> cont;
			if (cont != 'Y' && cont != 'y' && cont != 'N' && cont != 'n')
				cout << "User input invlaid" << endl;
			if (cont == 'Y' || cont == 'y')
				go = true;
			else if (cont == 'N' || cont == 'n')
				go = false;
		} while (cont != 'Y' && cont != 'y' && cont != 'N' && cont != 'n');

		cin.ignore();
	} while (go);
			
	system("pause");
	return 0;
}

