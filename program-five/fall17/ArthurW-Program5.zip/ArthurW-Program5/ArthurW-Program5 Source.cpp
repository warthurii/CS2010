//Name
//Course Name
//Course Time
//Program Number
//File Name
//Due Date
//Purpose
//Description of Input
//Description of Processing
//Description of Output

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

string menu();
string translateLine(string line);
string getNextWord(string line);
string translateWord(string word);
bool isVowel(char letter);
bool isPuncuation(char letter);
string splitWord(string, string);

int main()
{
	//Declaration Statement
	string phrase, choice, line, newWord;
	ifstream infile;

	choice = menu();
	
	if (choice == "1")
	{
		cout << "File Processed" << endl;
		infile.open("Program5Input.txt");

		for (int i = 0; i < 17; i++)
		{
			getline(infile, line);
			newWord = translateLine(line);
		}
		infile.close();
	}
	else if (choice == "2")
	{
		cout << "Your Sentence: ";
		cin.ignore();
		getline(cin, line);
		newWord = translateLine(line);
	}
	cout << newWord << endl;

	system("pause");
	return 0;
}

string menu()
{
	string choice, i;

	cout << setw(17) << "Menu:" << endl;
	for (int i = 0; i < 30; i++)
		cout << "=";
	cout << endl;
	cout << "[1] to process file" << endl;
	cout << "[2] to process single sentence" << endl;
	for (int i = 0; i < 30; i++)
		cout << "=";
	cout << endl;

	//User Choice
	do
	{
		cout << "Your Choice: ";
		cin >> choice;
		if (choice != "1" && choice != "2")
			cout << "User input invalid" << endl;
	} while (choice != "1" && choice != "2");
	return choice;
}

string translateLine(string line)
{
	string word, newWord;

	word = getNextWord(line);
	newWord = translateWord(word);
	return newWord;
}

string getNextWord(string line)
{
	char letter;
	string word;
	int length, i = 0;

	length = line.length();
	letter = 'a';
	while (letter != ' ')
	{
		letter = line[i];
		word += letter;
		i++;
	}
	return word;
}

string translateWord(string word)
{
	int length, i, sum;
	bool isVow, isPunc;
	char letter, finalLetter;
	string newWord = "", cons = "", halfWord = "";

	length = word.length();
	
	i = 0;
	letter = word[i];
	finalLetter = word[length - 1];

	isVow = isVowel(letter);
	isPunc = isPuncuation(letter);

	if (isVow == true && i == 0 && isalpha(finalLetter) == true)
	{
	newWord += "way";

	}
	else if (isVow == true && i == 0 && isalpha(finalLetter) == finalLetter)
	{
	for (int i = 0; i < length - 2; i++)
		newWord += word[i];
	newWord += finalLetter;
	}
	else if (isVow == false && i == 0)
	{
		sum = 0;
		i = 1;
		while (isVowel(letter) == false && letter != 'y' || letter != 'Y')
		{
			sum++;
			i++;
		}
		i = 0;
		while (i < sum)
		{
			cons += letter;
			i++;
		}
		i = sum;
		while (i < length - 1)
		{
			halfWord += letter;
			i++;
		}
		newWord = splitWord(cons, halfWord);
	}
	return newWord;
}

bool isVowel(char letter)
{
	bool isVow;

	if (letter == 'A' || letter == 'a' || letter == 'E' || letter == 'e' || letter == 'I' || letter == 'i' || letter == 'O' || letter == 'o' || letter == 'U' || letter == 'u')
		isVow = true;
	else
		isVow = false;
	return isVow;
}

bool isPuncuation(char letter)
{
	bool isPunc;

	if (letter > 65 && letter < 90 || letter > 97 && letter < 122)
		isPunc = false;
	else
		isPunc = true;
	return isPunc;
}
string splitWord(string cons, string halfWord)
{
	string newWord;
	newWord = halfWord + cons + "ay";
	return newWord;
}