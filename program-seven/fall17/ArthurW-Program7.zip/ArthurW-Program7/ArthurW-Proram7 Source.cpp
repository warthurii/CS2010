//Name				:Will Arthur
//Course			:CS 2010
//Class Time		:9:30-10:30	
//Program Number	:7
//File Name			:ArthurW-Program7
//Due Date			:Dec. 11, 2017
//Purpose			:Play Battleship

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

//Global Variables/Constants
const int MAX_COLS = 10, MAX_ROWS = 10;
const int REDPEN = 4, YELLOWPEN = 14, GREENPEN = 2, BLUEPEN = 9, ORANGEPEN = 12, WHITEPEN = 7, RED = 68, YELLOW = 238, GREEN = 34, BLUE = 153, ORANGE = 204;

//prototypes
void initGrid(char[][MAX_COLS]);
void setColor(int);
void drawGrid(char[][MAX_COLS]);
bool enterShips(char[][MAX_COLS], char[][MAX_COLS]);
bool validateCoordinates(char [][MAX_COLS], int, int);
bool checkShip(char[][MAX_COLS], int, int);

int main()
{
		//Declaration
		char ship[MAX_ROWS][MAX_COLS], guesses[MAX_ROWS][MAX_COLS];
		char cont = 'N';
		bool isWin;
		do
		{
			//Clearing Grids
			for (int i = 0; i < MAX_ROWS; i++)
				for (int j = 0; j < MAX_COLS; j++)
				{
					ship[i][j] = ' ';
					guesses[i][j] = ' ';
				}

			//Letting Player one choose the locations
			initGrid(ship);

			//Clearing screen
			system("cls");

			//Player 2 Guessing
			isWin = enterShips(ship, guesses);

			if (isWin)
				cout << "Congrats Player #2 you win!" << endl;
			else
				cout << "Sorry Player #2 you lose" << endl;
			do
			{
				cout << "Would you like to play again? Y(es) or N(o): ";
				cin >> cont;
				if (cont != 'Y' && cont != 'y' && cont != 'N' && cont != 'n')
					cout << "User input Invalid. Enter Y or N." << endl;
			} while (cont != 'Y' && cont != 'y' && cont != 'N' && cont != 'n');
		} while (cont == 'Y' || cont == 'y');
	system("pause");
	return 0;
}

void initGrid(char ship[][MAX_COLS])
{
	//Declaration
	char direction;
	int row, col;
	bool isOkay;

	//Menu
	cout << "You will enter 5 ships (1-5)" << endl << "Enter H(orizontal) or V(ertical)" << endl << "Then enter Row and Column coordinates" << endl << "Example: H 0 0 " << endl;

	for (int i = 1; i <= 5; i++)
	{
		do
		{
			cout << "Ship #" << i << " [" << i << "]: ";
			cin >> direction;
			cin >> row;
			cin >> col;
			isOkay = checkShip(ship, row, col);
			if (row < 0 || row > 9 || col < 0 || col > 9 || !isOkay)
				cout << "User input not valid. try again." << endl;
		} while (row < 0 || row > 9 || col < 0 || col > 9 || !isOkay);

		if (direction == 'H' || direction == 'h')
		{
			for (int j = 0; j < i; j++)
			{
				ship[row][col] = 'X';
				col++;
			}
		}

		else if (direction == 'V' || direction == 'v')
		{
			for (int j = 0; j < i; j++)
			{
				ship[row][col] = 'X';
				row++;
			}
		}
		drawGrid(ship);
	}
}

void setColor(int colorDesired)
{
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, colorDesired);
}

void drawGrid(char grid[][MAX_COLS])
{
	cout << " 00112233445566778899" << endl;
	for (int i = 0; i < MAX_ROWS; i++)
	{
		cout << i;
		for (int j = 0; j < MAX_COLS; j++)
		{
			if (grid[i][j] == 'X')
				setColor(YELLOWPEN);
			else if (grid[i][j] == 'H')
				setColor(REDPEN);
			else if (grid[i][j] == '*')
				setColor(GREENPEN);
			else if (grid[i][j] == ' ')
				setColor(BLUE);
			cout << grid[i][j] << grid[i][j];
			setColor(WHITEPEN);
		}
		cout << endl;
	}
}

bool enterShips(char ships[][MAX_COLS], char guesses[][MAX_COLS])
{
	int row, col, i = 0, sum = 0;
	bool isWin;

	cout << "Player #2 your job is to find the hidden ships" << endl;
	cout << "Do this by entering a set of corrdinates (row column)" << endl;
	cout << "Example: 0 0" << endl;
	cout << "Hit = H, Miss = *, and the rest is Empty Space" << endl;
	cout << "You get 30 guesses." << endl;

	while (i < 30 && sum < 15)
	{
		do
		{
			cout << "Guess #" << i << ": ";
			cin >> row;
			cin >> col;
			if (row < 0 || row > 9 || col < 0 || col > 9)
				cout << "User input invalid. Try again." << endl;
		} while (row < 0 || row > 9 || col < 0 || col > 9);
		if (validateCoordinates(ships, row, col) == true)
		{
			guesses[row][col] = 'H';
			sum++;
		}
		else if(validateCoordinates(ships, row, col) == false)
			guesses[row][col] = '*';
		i++;
		drawGrid(guesses);
	}
	if (i == 30 && sum < 15)
		isWin = false;
	else if (i < 30 && sum == 15)
		isWin = true;
	return isWin;
}

bool validateCoordinates(char ships[][MAX_COLS], int row, int col)
{
	bool isHit = false;

	if (ships[row][col] == 'X')
		isHit = true;

	return isHit;
}

bool checkShip(char ship[][MAX_COLS], int row, int col)
{
	if (col == 0 && row == 0)
	{
		if (ship[row + 1][col + 1] != ' ' || ship[row][col + 1] != ' ' || ship[row + 1][col] != ' ')
			return false;
		else
			return true;
	}
	else if (col == 0 && row != 0 && row != 9)
	{
		if (ship[row + 1][col + 1] != ' ' || ship[row + 1][col] != ' ' || ship[row - 1][col] != ' ' || ship[row][col + 1] != ' ' || ship[row - 1][col + 1] != ' ')
			return false;
		else
			return true;
	}
	else if (row == 9 && col == 0)
	{
		if (ship[row - 1][col] != ' ' || ship[row - 1][col + 1] != ' ' || ship[row][col + 1] != ' ')
			return false;
		else
			return true;
	}
	else if (row == 0 && col == 9)
	{
		if (ship[row][col - 1] != ' ' || ship[row + 1][col - 1] != ' ' || ship[row + 1][col] != ' ')
			return false;
		else
			return true;
	}
	else if(col == 9 && row != 0 && row != 9)
	{
		if (ship[row][col - 1] != ' ' || ship[row + 1][col - 1] != ' ' || ship[row + 1][col] != ' ' || ship[row - 1][col - 1] != ' ' || ship[row - 1][col] != ' ')
			return false;
		else
			return true;
	}
	else if (row = 0 && col == 9)
	{
		if (ship[row][col - 1] != ' ' || ship[row + 1][col - 1] != ' ' || ship[row + 1][col] != ' ')
			return false;
		else
			return true;
	}
	else if (row == 9 && col == 9)
	{
		if (ship[row][col - 1] != ' ' || ship[row - 1][col - 1] != ' ' || ship[row - 1][col] != ' ')
			return false;
		else
			return true;
	}
	else if (row != 0 && row != 9 && col != 0 && col != 9)
	{
		if (ship[row - 1][col - 1] != ' ' || ship[row - 1][col] != ' ' || ship[row - 1][col + 1] != ' ' || ship[row][col - 1] != ' ' || ship[row][col + 1] != ' ' || ship[row + 1][col - 1] != ' ' || ship[row + 1][col] != ' ' || ship[row + 1][col + 1] != ' ')
			return false;
		else
			return true;
	}
}
