/*
Brian Hubbard
Member 2
Program 6
CS 2010 Section 2
*/
//Include needed libraries
#include<iostream>
#include<string>
#include<iomanip>
#include<fstream>
using namespace std;

//Declare global constant
const int maxSize = 30;


//Prototype functions
void getShipData(string [], int [], int [], int[]);
int averageCapacity(int[]);
void showShipCapacity(int, string[], int[]);


int main()
{
	//Initialize vars
	string shipName[maxSize];
	int capacity[maxSize] = { 0 }, tonnage[maxSize], speed[maxSize], aveCap;
	
	//Call first function to get data for arrays
	getShipData(shipName, capacity, tonnage, speed);
	

	//Call second function to find the average capacity of ships and save that to a variable, also display average to the user
	aveCap = averageCapacity(capacity);
	cout << "The average capacity of the ships in the file was: " << aveCap << endl;

	//Call final function that displays ships over saved var aveCap.
	showShipCapacity(aveCap, shipName, capacity);

	//End of program
	system("pause");
	return.0;
}

void getShipData(string shipName[],int capacity [], int tonnage[], int speed[])
{
	//Initialize vars
	int i = 0;

	//Open file
	ifstream infile;
	infile.open("fleet.dat");
	
	//File loop to gather info
	while (!infile.eof())
	{
		infile >> shipName[i];
		infile >> capacity[i];
		infile >> tonnage[i];
		infile >> speed[i];
		i++;

	}
	//Close file and end funciton, no return needed since arrays default to var&
	infile.close();
}
int averageCapacity(int capacity[])
{
	//Initialize vars
	int average, k = 0, sum = 0, i = 0;

	//Begin loop to find the average capacity, using k and i as a counter instead of using "break;"
	while (i < (maxSize))
	{
		if (capacity[i] != 0)
		{
			sum += capacity[i];
			k++;
		}
		i++;
	}
	//Computing average
	average = sum / k;

	//Returning the average to main to be saved in a vairable.
	return average;
}
void showShipCapacity(int aveCap, string shipName[], int capacity[])
{
	//Initialize vars
	int i = 0;

	//Cout statement with correct formating for the following loop
	cout << "Ships with above average capacity" << endl << "+++++++++++++++++++++++++++++++++" << endl;

	//Loop to display the ships with above average capacity
	while (i < maxSize)
	{
		if (capacity[i] > (aveCap))
			cout << shipName[i] << "    " << "\t\t" << capacity[i] << endl;
		i++;
	}
}