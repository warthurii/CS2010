//Mitchell Pandy, CS1020, 8:30
//Program 6, Pandy_Program6_Member3.cpp, 3/12/17
//Track boat data from a cruise company
//input: a data input file

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

int getShipData(string [], int [], int [], int []);
int getHighestSpeed(int[], int);
void showShipSpeed(string[], int[], int);
void showShipCategories(string[], int[], int[], int[]);
void shipType(string[], int[]);

int main()
{
	const int ARRAY_SIZE = 30;
	int shipCap[ARRAY_SIZE], shipWeight[ARRAY_SIZE], shipSpeed[ARRAY_SIZE], shipAmount, shipNumber;
	string shipName[ARRAY_SIZE];

	shipAmount = getShipData(shipName, shipCap, shipWeight, shipSpeed);
	shipNumber = getHighestSpeed(shipSpeed, shipAmount);
	showShipSpeed(shipName, shipSpeed, shipNumber);

	system("pause");
	return 0;
}

int getShipData(string shipName[], int shipCap[], int shipWeight[], int shipSpeed[])
{
	ifstream infile;
	infile.open("fleet.dat");
	int i = 0, shipValue;
	string shipNameValue;
		while (!infile.eof())
	{
			infile >> shipNameValue;
			shipName[i] = shipNameValue;

			infile >> shipValue;
			shipCap[i] = shipValue;

			infile >> shipValue;
			shipWeight[i] = shipValue;

			infile >> shipValue;
			shipSpeed[i] = shipValue;

			i++;
	}

	return i;
}
int getHighestSpeed(int shipSpeed[], int shipAmount)
{
	int fastestShip, shipHigh = INT_MIN;
	for (int i = 0; i < shipAmount; i++)
	{
		if (shipSpeed[i] > shipHigh)
		{
			fastestShip = i;
			shipHigh = shipSpeed[i];
		}
	}

	return fastestShip;
}
void showShipSpeed(string shipName[], int shipSpeed[], int shipNumber)
{
	cout << "The fastest ship is " << shipName[shipNumber] << " at " << shipSpeed[shipNumber];

}
void showShipCategories(string shipName[], int shipCap[], int shipWeight[], int shipSpeed[])
{


}
void shipType(string shipName[], int shipWeight[])
{


}

