//Name					:Will Arthur
//Course Name			:CS 2010
//Class Time			:9:30-10:30
//Program Number		:6
//File Name				:ArthurW-Program6-Member1
//Purpose of Program	:Retrieve and Output ship data
//Input Data			:
//Process				:
//Output				:

#include <iomanip>
#include <iostream>
#include <string>
#include <fstream>

using namespace std;
//Prototype
int getShipData(string[], int[], int[], int[]);
void showShipCategories(string[], int[], int[], int[], int);
string getCategory(int);
double averageCapacity(int[], int);
void showShipCapacity(string[], int[], int, int);
void getHighestSpeed(string[], int[], int[], int, int&);
void showShipSpeed(string[], int[], int[], int);

int main()
{
	//Declaration
	const int MAX = 30;
	string name[MAX] = { "" };
	int size, speedSize = 0, at[MAX], capacity[MAX] = { 0 }, tonnage[MAX] = { 0 }, speed[MAX] = { 0 };
	double aveCap;

	size = getShipData(name, capacity, tonnage, speed);

	showShipCategories(name, capacity, tonnage, speed, size);

	aveCap = averageCapacity(capacity, size);

	cout << endl;

	showShipCapacity(name, capacity, aveCap, size);

	getHighestSpeed(name, speed, at, size, speedSize);

	showShipSpeed(name, speed, at, speedSize);

	system("pause");
	return 0;
}

int getShipData(string name[], int capacity[], int tonnage[], int speed[])
{
	int i = 0;
	ifstream infile;

	infile.open("fleet.DAT");

	while (!infile.eof())
	{
		infile >> name[i];
		infile >> capacity[i];
		infile >> tonnage[i];
		infile >> speed[i];
		i++;
	}
	return i;
}

void showShipCategories(string name[], int capacity[], int tonnage[], int speed[], int size)
{
	int num;

	cout << "        " << "Category" << setw(13) << "Name" << setw(16) << "Capacity" << setw(9) << "Tonnage" << setw(8) << "Speed" << endl;
	cout << "        " << "++++++++" << setw(13) << "++++" << setw(16) << "++++++++" << setw(9) << "+++++++" << setw(8) << "+++++" << endl;

	for (int i = 0; i < size; i++)
	{
		num = tonnage[i];
		cout << setw(16) << getCategory(num) << setw(13) << name[i] << setw(16) << capacity[i] << setw(9) << tonnage[i] << setw(8) << speed[i] << endl;
	}
}

string getCategory(int num)
{
	if (num < 48600)
		return "Empress Family";
	else if (num >= 48600 && num < 74000)
		return "Sovereign Family";
	else if (num >= 74000 && num < 90100)
		return "Vision Family";
	else if (num >= 90100 && num < 138000)
		return "Radiance Family";
	else if (num >= 138000 && num < 155000)
		return "Voyager Family";
	else if (num >= 155000 && num < 160666)
		return "Freedom Family";
	else if (num >= 160666)
		return "Oasis Family";
}

double averageCapacity(int capacity[], int size)
{
	int sum = 0;

	for (int i = 0; i < size; i++)
	{
		sum += capacity[i];
	}

	return sum / size;
}

void showShipCapacity(string name[], int capacity[], int aveCap, int size)
{
	//Initialize vars
	int i = 0;

	cout << "Average Capacity is " << aveCap << endl;
	//Cout statement with correct formating for the following loop
	cout << "Ships with above average capacity" << endl << "+++++++++++++++++++++++++++++++++" << endl;

	//Loop to display the ships with above average capacity
	while (i < size)
	{
		if (capacity[i] >(aveCap))
			cout << setw(9) << name[i] << setw(9) << capacity[i] << endl;
		i++;
	}
}

void getHighestSpeed(string name[], int speed[], int at[], int size, int & speedSize)
{
	int shipHigh = 0;
	for (int i = 0; i < size; i++)
	{
		if (speed[i] > shipHigh)
		{
			shipHigh = speed[i];
		}
	}
	for (int i = 0; i < size; i++)
	{
		if (speed[i] == shipHigh)
		{
			at[i] = i;
			speedSize++;
		}
	}
}
void showShipSpeed(string name[], int speed[], int at[], int speedSize)
{
	cout << "Ships With Highest Cruising Speeds" << endl << "++++++++++++++++++++++++++++++++++" << endl;
	for (int i = 0; i < speedSize; i++)
	{
		cout << setw(10) << name[at[i]] << setw(10) << speed[at[i]] << endl;
	}
}
