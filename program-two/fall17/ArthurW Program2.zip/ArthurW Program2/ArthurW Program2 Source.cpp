//Author:		Will Arthur
//Course:		CS 2010
//Class:		9:30-10:20
//Assignment:	Program 2
//File Name:	ArthurW Program2
//Due Date:		October 8, 2017
//Purpose:		This program will be calculating the monthly loan payment for the user.
//Input Data:	For this to work the program will need the amount of payments, the loan amount, and the loan type.
//Calculations:	This program makes calculations for monthly payment, amount of payments, total payment, and interest paid.
//Results:		The results are all good and correct calculations. The uses will get correct results in between 0 and 1000000000 dollars.

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include <fstream>

using namespace std;

int main()
{
	//Declaration Statement
	double rate;
	double finalRate;
	int loanPayments;
	char loanType;
	int loanYears;
	double loanAmount;
	ofstream outFile;

	//Gathering Infromation
	cout << "What type of loan do you have? (Insert A for Auto or H for Home): ";
	cin >> loanType;
	cout << "How much do you need to borrow?: ";
	cin >> loanAmount;
	if (loanType == 'A')
	{
		cout << "How many payments? (36,48, or 60): ";
		cin >> loanPayments;
	}
	else if(loanType == 'H')
	{
		cout << "How many years? (15,20, or 30): ";
		cin >> loanYears;
		loanPayments = loanYears * 12;
	}

	//Determining the rate
	{
		if (loanType == 'A')
		{
			if (loanPayments == 36)
			{
				rate = .0299;
			}
			else if (loanPayments == 48)
			{
				rate = .0302;
			}
			else if (loanPayments == 60)
			{
				rate = .0389;
			}

		}
		else if(loanType == 'H')
		{
			if (loanYears == 15)
			{
				rate = .0312;
			}
			else if (loanYears == 20)
			{
				rate = .03625;
			}
			else if (loanYears == 30)
			{
				rate = .0387;
			}
		}
	}
	{
		if (loanAmount > 200000)
		{
			finalRate = rate + .015;
		}
		else
		{
			finalRate = rate;
		}
	}

	//Calculations
	double monthlyPayment = ((finalRate * pow(1 + finalRate, loanPayments)) / (pow(1 + finalRate, loanPayments) - 1)) * loanAmount;
	double ratePercentage = finalRate * 100;
	double totalPayment = (1 + finalRate) * loanAmount;
	double interestPaid = loanAmount * finalRate;

	//Opening Outfile
	outFile.open("report.txt");

	//Displaying the information
	cout << "--- " << "Loan Report" << " ---" << endl;
	if (loanType == 1)
	{
		cout << "Loan Type:" << setw(60) << "Auto" << endl;
		outFile << "Loan Type:" << setw(60) << "Auto" << endl;
	}
	else
	{
		cout << "Loan Type:" << setw(60) << "Home" << endl;
		outFile << "Loan Type:" << setw(60) << "Home" << endl;
	}
	if (loanAmount >= 0 && loanAmount < 10)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(3) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(3) << loanAmount << endl;
	}
	else if (loanAmount >= 10 && loanAmount < 100)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(4) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(4) << loanAmount << endl;
	}
	else if (loanAmount >= 100 && loanAmount < 1000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(5) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(5) << loanAmount << endl;
	}
	else if (loanAmount >= 1000 && loanAmount < 10000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(6) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(6) << loanAmount << endl;
	}
	else if (loanAmount >= 10000 && loanAmount < 100000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(7) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(7) << loanAmount << endl;
	}
	else if (loanAmount >= 100000 && loanAmount < 1000000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(8) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(8) << loanAmount << endl;
	}
	else if (loanAmount >= 1000000 && loanAmount < 10000000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(9) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(9) << loanAmount << endl;
	}
	else if (loanAmount >= 10000000 && loanAmount < 100000000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(10) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(10) << loanAmount << endl;
	}
	else if (loanAmount >= 100000000 && loanAmount < 1000000000)
	{
		cout << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(11) << loanAmount << endl;
		outFile << "Loan Amount:" << setw(24) << "$" << setw(34) << showpoint << setprecision(11) << loanAmount << endl;
	}
	cout << "Annual Interest Rate:" << setw(48) << setprecision(3) << ratePercentage << "%" << endl;
	outFile << "Annual Interest Rate:" << setw(48) << setprecision(3) << ratePercentage << "%" << endl;
	cout << "Number of Payments" << setw(52) << loanPayments << endl;
	outFile << "Number of Payments" << setw(52) << loanPayments << endl;
	if (monthlyPayment >= 0 && monthlyPayment < 10)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(3) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(3) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 10 && monthlyPayment < 100)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(4) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(4) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 100 && monthlyPayment < 1000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(5) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(5) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 1000 && monthlyPayment < 10000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(6) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(6) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 10000 && monthlyPayment < 100000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(7) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(7) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 100000 && monthlyPayment < 1000000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(8) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(8) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 1000000 && monthlyPayment < 10000000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(9) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(9) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 10000000 && monthlyPayment < 100000000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(10) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(10) << monthlyPayment << endl;
	}
	else if (monthlyPayment >= 100000000 && monthlyPayment < 1000000000)
	{
		cout << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(11) << monthlyPayment << endl;
		outFile << "Monthly Payment:" << setw(20) << "$" << setw(34) << showpoint << setprecision(11) << monthlyPayment << endl;
	}
	if (totalPayment >= 0 && totalPayment < 10)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(3) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(3) << totalPayment << endl;
	}
	else if (totalPayment >= 10 && totalPayment < 100)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(4) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(4) << totalPayment << endl;
	}
	else if (totalPayment >= 100 && totalPayment < 1000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(5) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(5) << totalPayment << endl;
	}
	else if (totalPayment >= 1000 && totalPayment < 10000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(6) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(6) << totalPayment << endl;
	}
	else if (totalPayment >= 10000 && totalPayment < 100000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(7) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(7) << totalPayment << endl;
	}
	else if (totalPayment >= 100000 && totalPayment < 1000000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(8) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(8) << totalPayment << endl;
	}
	else if (totalPayment >= 1000000 && totalPayment < 10000000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(9) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(9) << totalPayment << endl;
	}
	else if (totalPayment >= 10000000 && totalPayment < 100000000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(10) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(10) << totalPayment << endl;
	}
	else if (totalPayment >= 100000000 && totalPayment < 1000000000)
	{
		cout << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(11) << totalPayment << endl;
		outFile << "Total Payment:" << setw(22) << "$" << setw(34) << showpoint << setprecision(11) << totalPayment << endl;
	}
	if (interestPaid >= 0 && interestPaid < 10)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(3) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(3) << interestPaid << endl;
	}
	else if (interestPaid >= 10 && interestPaid < 100)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(4) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(4) << interestPaid << endl;
	}
	else if (interestPaid >= 100 && interestPaid < 1000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(5) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(5) << interestPaid << endl;
	}
	else if (interestPaid >= 1000 && interestPaid < 10000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(6) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(6) << interestPaid << endl;
	}
	else if (interestPaid >= 10000 && interestPaid < 100000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(7) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(7) << interestPaid << endl;
	}
	else if (interestPaid >= 100000 && interestPaid < 1000000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(8) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(8) << interestPaid << endl;
	}
	else if (interestPaid >= 100000 && interestPaid <= 10000000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(9) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(9) << interestPaid << endl;
	}
	else if (interestPaid >= 10000000 && interestPaid < 100000000)
	{
		cout << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(10) << interestPaid << endl;
		outFile << "Interest Paid:" << setw(22) << "$" << setw(34) << showpoint << setprecision(10) << interestPaid << endl;
	}

	//Close Outfile
	outFile.close();

	system("pause");
	return 0;
}