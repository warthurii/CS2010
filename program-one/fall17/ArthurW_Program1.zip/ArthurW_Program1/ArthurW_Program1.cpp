//Assignment:	Program 1
//File Name:	ArthurW_Program1
//Author:		Will Arthur
//Date:			September 20, 2017
//Purpose:		This program will say hello to the user in a border of asterisks

#include <iostream>
#include <string>

using namespace std;

int main()
{
	//Declaring Variables
	string first, last;

	//Get User's Name
	cout << "Insert first name: ";
	cin >> first;
	cout << "Insert last name: ";
	cin >> last;

	//Display Message
	cout << "**************************************" << endl;
	cout << "**" << "             H E L L O            " << "**" << endl;
	cout << "**" << "            " << first << " " << last << "           " << "**" << endl;
	cout << "**************************************" << endl;

	system("pause");
	return 0;
}